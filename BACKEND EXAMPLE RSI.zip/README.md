# RSOI-backend
The backend for the Robotic Society of India's backend
